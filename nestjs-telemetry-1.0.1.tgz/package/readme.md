**NestJS Telemetry Module**
